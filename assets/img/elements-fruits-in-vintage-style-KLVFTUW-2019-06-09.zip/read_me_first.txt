Thank you for purchasing my project! Hope you enjoy it.

Fruits in vintage style, vector illustration.
Colored and Line art versions.

Set includes:

- Banana
- Green apple
- Red apple
- Green grapes
- Red grapes
- Kiwi
- Limon
- Orange
- Peach
- Pear
- Pineapple
- Plum
- Pomegranate


File formats: AI CS3 (Vector), EPS 10 (Vector) and JPG (5000X5000px)

Have a nice day! :)
